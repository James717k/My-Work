/**
 * Provides list implementations.
 */
package csi213.projects.lists;