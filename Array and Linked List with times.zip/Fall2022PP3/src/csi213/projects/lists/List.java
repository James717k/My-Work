package csi213.projects.lists;

import java.util.Iterator;

public interface List<E> extends Iterable<E> {

	int size();

	void add(int index, E element);
	void add(E element);

	E get(int index);

	E remove(int index);

	Iterator<E> iterator();

}
