package csi213.projects.lists;
import java.util.Iterator;




/**
 * A {@code LinkedList} represents a sequence of elements using {@code Node}s holding an element and a link to the next
 * {@code Node} if any.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 *
 * @param <E>
 *            the type of elements
 */
public class LinkedList<E> implements List<E> {
	
	/**
	 * The time (in nanoseconds) when sorting completed.
	 */
	static long completionTime;
	static long startTime;

	static long runTime;

	/**
	 * A {@code Node} in a {@code LinkedList} holds an element and a link to the next {@code Node} if any.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 *
	 */
	class Node {

		/**
		 * The element that this {@code Node} holds.
		 */
		E element;

		/**
		 * The next {@code Node}.
		 */
		Node next;

		/**
		 * Constructs a {@code Node}.
		 * 
		 * @param element
		 *            the element that the {@code Node} needs to hold
		 * @param next
		 *            the next {@code Node}
		 */
		public Node(E element, Node next) {
			this.element = element;
			this.next = next;
		}
	}

	/**
	 * The number of elements in this {@code LinkedList}.
	 */
	int size;

	/**
	 * The first {@code Node} in this {@code LinkedList}.
	 */
	Node first;

	/**
	 * The last {@code Node} in this {@code LinkedList}.
	 */
	Node last;

	/**
	 * Constructs a {@code LinkedList}.
	 */
	public LinkedList() {
		startTime = System.nanoTime();
		size = 0;
		first = null;
		last = null;
		completionTime= System.nanoTime();
	}
	public long duration() {
		return completionTime - startTime;
	}

	/**
	 * Returns the number of elements in this {@code LinkedList}.
	 * 
	 * @return the number of elements in this {@code LinkedList}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Appends the specified element to the end of this {@code LinkedList}.
	 *
	 * @param element
	 *            the element to be appended to this {@code LinkedList}
	 */
	@Override
	public void add(E element) {
		// TODO: add some code here
		startTime = System.nanoTime();
		if (first == null) { // if the list is empty
			first = new Node(element, null);
			last = first;
			} else { // add to the end of the list
			last.next = new Node(element, null);
			last = last.next;
			}
			size++;
			completionTime= System.nanoTime();
	}

	/**
	 * Returns a string representation of this {@code LinkedList}.
	 * 
	 * @return a string representation of this {@code LinkedList}
	 */
	@Override
	public String toString() {
		String s = "(";
		Node n = first;
		while (n != null) {
			s += n.element + (n.next == null ? "" : ", ");
			n = n.next;
		}
		return s + ")";
	}

	/**
	 * Returns the element at the specified position in this {@code LinkedList}.
	 *
	 * @param index
	 *            the index of the element to return
	 * @return the element at the specified position in this {@code LinkedList}
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index >= size()})
	 */
	@Override
	public E get(int index) {
		// TODO: add some code here
		startTime = System.nanoTime();

		if(index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException(); 
		}
		Node n= first;
		for(int i = 0; i<index;i++)
		n=n.next;
		completionTime= System.nanoTime();
		return n.element;
	
		
	}

	/**
	 * Inserts the specified element at the specified position in this {@code LinkedList}. Shifts the element currently
	 * at that position (if any) and any subsequent elements to the right (adds one to their indices).
	 *
	 * @param index
	 *            the index at which the specified element is to be inserted
	 * @param element
	 *            the element to be inserted
	 * @return 
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index > size()})
	 */
	@Override
	public void add(int index, E element) {
		// TODO: add some code here
		startTime = System.nanoTime();
		if (index < 0 || index > size())
			throw new IndexOutOfBoundsException();

		if(index==0) {
			first= new Node(element,first);
			if(last==null)
				last=first;



			
		}else {
			
		Node n = first;
		for(int k =1; k<index; k++) 
			n=n.next;
			n.next= new Node(element,n.next);
			
			if(n.next.next ==null)
				last = n.next;
			
		
		}
		size++;
		completionTime= System.nanoTime();

	}
	
	/**
	 * This method allows the add method to add to the front. 
	 * @param l list of integers. 
	 * @param size of the list
	 */
public static void addFront(LinkedList<Integer> l, int size){
	for ( int i = 0 ; i < size ; i++)
		l.add( 0 , i ) ;
}
/**
 * This method allows the add method to add from the back. 
 * @param l list of integers. 
 * @param size of the list
 */
public static void addBack(LinkedList<Integer> l, int size) {
	for ( int i = 0 ; i < size ; i++)
		l.add ( l . size ( ) , i ) ;
}
/**
 * This method allows the remove method to remove from the front. 
 * @param l list of integers. 
 * @param size of the list
 */
public static void removeFront(LinkedList<Integer> l, int size) {
	for ( int i = 0 ; i < size ; i++)
		l.remove(l.size() - 1);
}
/**
 * This method allows the remove method to remove from the back. 
 * @param l list of integers. 
 * @param size of the list
 */
public static void removeBack(LinkedList<Integer> l, int size) {
	for ( int i = 0 ; i < size ; i++)
		l.remove(l.size() - 1);
}
	/**
	 * Removes the element at the specified position in this {@code LinkedList}. Shifts any subsequent elements to the
	 * left (subtracts one from their indices). Returns the element that was removed from this {@code LinkedList}.
	 *
	 * @param index
	 *            the index of the element to be removed
	 * @return the element previously at the specified position
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index >= size()})
	 */
	@Override
	public E remove(int index) {
		// TODO: add some code here
		startTime = System.nanoTime();
		if (index < 0 || index >= size())
			throw new IndexOutOfBoundsException();
			E element;
			if (index == 0) { // removal of first item in the list
			element = first.element;
			first = first.next;
			if (first == null) // if the list is empty
			last = null;
			} else {
			// find the predecessor of the element to be removed.
			Node pred = first;
			for (int k = 1; k < index; k++)
			pred = pred.next;
			element = pred.next.element;
			// route link around the node to be removed
			pred.next = pred.next.next;
			if (pred.next == null) // if pred is at the end of the list
			last = pred;
			}
			size--;
			completionTime= System.nanoTime();
			return element;
		
	}

	/**
	 * Returns an {@code Iterator} over the elements in this {@code LinkedList}.
	 *
	 * @return an {@code Iterator} over the elements in this {@code LinkedList}
	 */
	public Iterator<E> iterator() {
		return new Iterator<E>() {

			Node n = first;

			@Override
			public boolean hasNext() {
				// TODO: add some code here
				
				return n != null;
			}

			@Override
			public E next() {
				E next = n.element;
				n = n.next;
				return next;
			}

		};
	}

	/**
	 * The main method of the {@code LinkedList} class.
	 * 
	 * @param args
	 *            the program arguments
	 * @throws Exception
	 *             if an error occurs
	 * @param startTime stores start time of the code
	 * @param complection time stores the time it takes to end the code
	 * @param runTime is how long it takes the code to run as a whole. 
	 */
	public static void main(String[] args) throws Exception {
		
		LinkedList<String> l = new LinkedList<String>();
		
		
		System.out.println(l.size());
		
		System.out.println(l);
		
		l.add(0, "1");
		
		
		
	System.out.println(l.get(0));
	
	System.out.println(l.remove(0));
	
		l.add("a");
	
		System.out.println(l);
		
		l.add("b");
		
		System.out.println(l);
		
		try {
			System.out.println(l.get(0));
		
			System.out.println(l.get(1));
			
			System.out.println(l.get(2));
		} 
			catch (Exception e) {
			
			e.printStackTrace(System.out);
		}

		try {
			l.add(0, "?");
			
			System.out.println(l);
			
			l.add(3, "c");
			
			System.out.println(l);
			
			l.add(5, "e");
		} 
		catch (Exception e) {
		
			e.printStackTrace(System.out);
		}

		try {
			l.remove(3);
			System.out.println(l);
			l.remove(0);
			System.out.println(l);
			l.remove(3);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}

		Iterator<String> i = l.iterator();
		while (i.hasNext())
			System.out.println(i.next());
		System.out.println();

		for (String s : l)
			System.out.println(s);
		

		LinkedList<Integer> A = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addFront(A,1000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("add 1000 to the front"+ " " +  runTime+" "+"nanoseconds");
		 
		
		LinkedList<Integer> B = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addBack(B,1000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("add 1000 to the back"+ " " +  runTime+" "+ "nanoseconds");

		LinkedList<Integer> C = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addFront(C,1000);
		removeFront(C,1000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("remove 1000 time from the front"+ " " +  runTime+" "+ "nanoseconds");
		
		LinkedList<Integer> D = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addBack(D,1000);
		removeBack(D,1000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("remove 1000 time from the back"+ " " + runTime+" "+"nanoseconds");
		

		
		
		
		
		
		LinkedList<Integer> E = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addFront(E,5000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("add 5000 to the front"+ " " +  runTime+" "+"nanoseconds");
		 
		
		LinkedList<Integer> F = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addBack(F,5000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("add 5000 to the back"+ " " +  runTime+" "+ "nanoseconds");

		LinkedList<Integer> G = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addFront(G,5000);
		removeFront(G,5000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("remove 5000 time adding and removing from the front"+ " " +  runTime+" "+ "nanoseconds");
		
		LinkedList<Integer> H = new LinkedList<Integer>();

		startTime=System.nanoTime();
		addBack(H,5000);
		removeBack(H,5000);
		completionTime=System.nanoTime();
		runTime= completionTime-startTime;
		System.out.println();
		System.out.print("remove 5000 time adding and removing from the back"+ " " + runTime+" "+"nanoseconds");
		
	}
	
}

