
import java.util.Iterator;

/**
 * A {@code List} is a sequence of elements. This {@code List} interface is a simplified version of the
 * {@link java.util.List} interface in the {@link java.util} package.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 *
 * @param <E>
 *            the type of elements
 */
public interface List<E> extends Iterable<E> {

	/**
	 * Returns the number of elements in this {@code List}.
	 * 
	 * @return the number of elements in this {@code List}
	 */
	int size();

	/**
	 * Appends the specified element to the end of this {@code List}.
	 *
	 * @param element
	 *            the element to be appended to this {@code List}
	 */
	void add(E element);

	/**
	 * Returns the element at the specified position in this {@code List}.
	 *
	 * @param index
	 *            the index of the element to return
	 * @return the element at the specified position in this {@code List}
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index >= size()})
	 */
	E get(int index);

	/**
	 * Inserts the specified element at the specified position in this {@code List}. Shifts the element currently at
	 * that position (if any) and any subsequent elements to the right (adds one to their indices).
	 *
	 * @param index
	 *            the index at which the specified element is to be inserted
	 * @param element
	 *            the element to be inserted
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index > size()})
	 */
	void add(int index, E element);

	/**
	 * Removes the element at the specified position in this {@code List}. Shifts any subsequent elements to the left
	 * (subtracts one from their indices). Returns the element that was removed from this {@code List}.
	 *
	 * @param index
	 *            the index of the element to be removed
	 * @return the element previously at the specified position
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range ({@code index < 0 || index >= size()})
	 */
	E remove(int index);

	/**
	 * Returns an {@code Iterator} over the elements in this {@code List}.
	 *
	 * @return an {@code Iterator} over the elements in this {@code List}
	 */
	Iterator<E> iterator();

}
