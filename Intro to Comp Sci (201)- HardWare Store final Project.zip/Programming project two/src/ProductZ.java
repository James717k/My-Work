import java.util.Scanner;

public class ProductZ extends Products {
    private final boolean promotion;

    public ProductZ(int productID,String productName, String type, int amount,double price,boolean promotion) {
    	    
    	    	super(productID,productName,type,amount,price);
    
    	    	this.promotion = promotion;
    }

    @Override
	double getTotalPrice() {
		// TODO Auto-generated method stub
    	//System.out.println(promotion);
			if (promotion) {
				//System.out.println("Here1");
	            return (price*amount)/2;
	            
	            
	        }else {
	        	//System.out.println("Here2");
	        	return price*amount;
	        }
		}
		
	}

   



	

    
