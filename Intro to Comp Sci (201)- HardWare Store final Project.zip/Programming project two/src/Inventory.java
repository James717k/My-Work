

public class Inventory {
    String name;
    double regularPrice;

    public String getName() {
        return name;
    }

    public double getRegularPrice() {
        return regularPrice;
    }

    public Inventory(String name, double regularPrice) {
        this.name = name;
        this.regularPrice = regularPrice;
    }
}