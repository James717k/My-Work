import java.util.Scanner;

public class ProductX extends Products {
    
    

    public ProductX(int productID,String productName, String type, int amount,double price ) {
     
    	super(productID,productName,type,amount,price);
    }
    //int productID,String productName, String type, int amount,double price
    @Override 
    double getTotalPrice() {
    	
    	return price*amount; 
    	
    }
  
    

	
   
 
    


	}

