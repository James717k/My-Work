import java.util.Scanner;

public class ProductY extends Products {

    public ProductY(int productID,String productName, String type, int amount,double price) {
    	super(productID,productName,type,amount,price);
    }	
 
    @Override
    
	double getTotalPrice() {
  
		// TODO Auto-generated method stub
		  if(this.amount<100) {
			 // System.out.println("here10");
		  return price*amount;
		  
		} else if (amount>100 && amount<500) {
			//System.out.println("Here for more than 100 less than 500");
		  return price *amount *.95;
			
		} else if (amount>500 && amount<1500) {
			System.out.println("Here2");
		  return price *amount*.85;		
			
			} else {
				//System.out.println("Here3");
				return price * amount*.75;
				
	        }	
		  
			}
		
	

    public void display() {

        if (amount < 100) {
    
            System.out.printf("If you buy more than 100 units you would pay $%.2f per unit\n", price*0.95);
            System.out.printf("If you buy more than 500 units you would pay $%.2f per unit\n", price*0.85);
            System.out.printf("If you buy more than 1500 units you would pay $%.2f per unit\n", price*0.75);
        } else if (amount < 500) {
        	
            price *= 0.95;
            System.out.printf("If you buy more than 500 units you would pay $%.2f per unit\n", price*0.85);
            System.out.printf("If you buy more than 1500 units you would pay $%.2f per unit\n", price*0.75);
        } else if (amount < 1500){
            price *= 0.85;
            System.out.printf("If you buy more than 1500 units you would pay $%.2f per unit\n", price*0.75);
        } else {
            price *= 0.75;
        }
        String nameofUser = null;
        
        System.out.println("Whats your name?");
        
         Scanner sc2 = new Scanner(System.in);
        
         nameofUser = sc2.next();
        
         double result = price*amount;
        
         int dollars = (int)result;
        
         double centsInDouble = (result - dollars)*100;
        
        int cents;
        
        if (centsInDouble - (int)centsInDouble >= 0.5) {
        
        	cents = (int)centsInDouble + 1;
        } 
        else {
            cents = (int)centsInDouble;
        }
        
         System.out.printf("The total amount for your order"  +" "+ nameofUser + " " + "is %d dollars and %d cents\n", dollars, cents);
    }



	

   
}