import java.util.Scanner;

/**
 * This is what your Product super class would look like. It should consist of all common properties for each product.
 * It should also contain any methods shared for each product sub class.
 * As well as any abstract methods that will overriden by each sub class.
 */

// 1 - abstract denotes the super class with abstact methods to override
public abstract class Products {

    // 2 - Common properties shared by each product would be something like the below.
    protected static double price; //Protected access ensures accessible by subclasses
    protected static int amount;
    protected static String productName;
    protected static int productID;
    protected static String type;


    // 3 - Build your constuctor how you would with your sub classes, but only with shared properties from above.
    public Products(int productID,String productName, String type, int amount,double price) {
    	this.productID=productID;
    	this.productName=productName;
    	this.type=type;
    	this.price=price;
    	this.amount=amount; 
    }

    // 4 - Include your getter and setter methods for each property above as needed. Can be copied from any sub class

    // 5 - This is your abstract method that will need to be overridden and implemented by each sub class
    abstract double getTotalPrice();
    
    public double getPrice() {
        return price;
        
    }
    
    public double setTotalPrice() {
		return getTotalPrice();
    	
    }
    

    public void setPrice(double price) {
        this.price = price;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    public int getAmount() {
        return amount;
    }
    
    
    public int setProductID(int productID) {
		return this.productID=productID;
    	 }
    	public int getProductID(int productID) {
		return productID;
    	 }
    
    
    public String setproductName(String productName) {
    	return this.productName=productName;
    	}
    public String getproductName(String productName) {
    	return productName; }
    
    
    public String settype(String type) {
    	return this.type=type;
    }
    public static String gettype() {
    	return type;
    }
    
    public void display() {
    	String nameofUser = null; 
    	
         System.out.println("Whats your name?");
         Scanner sc2 = new Scanner(System.in);
         nameofUser = sc2.next();
        double result = getTotalPrice();
        int dollars = (int)result;
        double centsInDouble = (result - dollars)*100;
        int cents;
        if (centsInDouble - (int)centsInDouble >= 0.5) {
            cents = (int)centsInDouble + 1;
        } else {
            cents = (int)centsInDouble;
        }
      
        System.out.printf("The total amount for your order"  +" "+ nameofUser + " " + "is %d dollars and %d cents\n", dollars, cents);
	
  
        
    }



    
    // 6 - Example of overriden toString() below. This can be used to print any properties common to the super class, and can subsquently be overriden in each sub class when needed
   @Override
   public String toString() {
	   
	   return "Product ID" + this.productID +
			   "Product Name" + this.productName +
			   "Amount: " + this.amount +
			   "Price: "+this.price +
			   "Type: "+this.type;
			   
	   
   }
}