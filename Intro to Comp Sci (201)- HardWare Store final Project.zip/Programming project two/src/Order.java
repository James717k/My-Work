import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
//ICSI 201. Introduction to Computer Science
//Semester: Spring 2022
//TA:Zhenfei Zhang
//James Krueger
//001541293

public class Order {

	protected static String username;
	protected static String date; 
	protected static int choice;
	protected static int totalUnits;
	User customer;
	ProductX X;
	ProductY Y;
	ProductZ Z;
	DateClass purchaseDate;

	public Order(User customer,ProductX X, DateClass purchaseDate) {
		this.customer=customer;
		this.X=X;
		this.purchaseDate=purchaseDate;
		
		
	}
	public Order(User customer,ProductY Y, DateClass purchaseDate) {
		this.customer=customer;
		this.Y=Y;
		this.purchaseDate=purchaseDate;
		
		
	}
	public Order(User customer,ProductZ Z, DateClass purchaseDate) {
		this.customer=customer;
		this.Z=Z;
		this.purchaseDate=purchaseDate;
		
		
	} 
	/* already did this in other products ]

	static double getTotalPrice() throws FileNotFoundException {
		  ArrayList<String> listOfStrings
	        = new ArrayList<String>();
	   
	    // load content of file based on specific delimiter
			 
	     // load content of file based on specific delimiter
	     Scanner sc = new Scanner(new FileReader("C:\\Users\\james\\Desktop\\Csi Work\\Testing\\src\\inv.txt"))
	                      .useDelimiter(",\\s*");
	     String str;
	    
	     // checking end of file
	     while (sc.hasNextLine()) {
	         str = sc.nextLine();
	        
	         // adding each string to arraylist
	         listOfStrings.add(str);
	     }
	     
		  
		  
		  
		  
			 String[] selection = listOfStrings.get(choice-1).split("\\|"); 
			 String productType = selection[3];
	    	return Double.valueOf(selection[2])*totalUnits; 
	    	*/
	    	//}
	
	/* already did this in other products ]
	public void display() throws FileNotFoundException {
	        double result = getTotalPrice();
	        int dollars = (int)result;
	        double centsInDouble = (result - dollars)*100;
	        int cents;
	        if (centsInDouble - (int)centsInDouble >= 0.5) {
	            cents = (int)centsInDouble + 1;
	        } else {
	            cents = (int)centsInDouble;
	        }
	        System.out.printf("The total amount is %d dollars and %d cents\n", dollars, cents);
	    }
	    	*/
	
	
	
	
	public void display() {
		System.out.println("*********************************");
		System.out.println("Date: " + purchaseDate.date2);
		System.out.println("*********************************");
		System.out.println(customer.getUserName()  );
		System.out.println("Your item: ");
		System.out.println("+----+--------------+------+----+");
		System.out.println("| ID | Name         |Price |Type|");
		System.out.println("+----+--------------+------+----+");
		
		
		//What has to be next to each other in a line unsure how to do
		System.out.print(Products.productID);
		System.out.print("  ");
		System.out.print(Products.productName);
		System.out.print("  ");
		System.out.print(Products.price);
		System.out.print("  ");
		System.out.print(Products.type);
		System.out.print("  ");
		System.out.println("");
		//line printed
		System.out.println("+----+--------------+------+----+");
		System.out.println("In the amount of " + Products.amount);
		System.out.println("");
		System.out.println("*********************************");
		 switch (Products.gettype())
         {
             case "Type X":
                 System.out.print("Your Total is " + X.getTotalPrice());
            
                 
				  break;
                 
	   		
             case "Type Y":
            	 System.out.printf("If you buy more than 100 units you would pay $%.2f per unit\n",  Products.price*0.95);
                 System.out.printf("If you buy more than 500 units you would pay $%.2f per unit\n",  Products.price*0.85);
                 System.out.printf("If you buy more than 1500 units you would pay $%.2f per unit\n", Products.price*0.75);
            	 System.out.print("Your Total is " + Y.getTotalPrice());
            	
                 break;
                 
             case "Type Z":
            	 System.out.print("Your Total is " + Z.getTotalPrice());
            	
            	 break;
              
				}
		 
         }


		
		
		
		
		
		
	
		
	
	
	public static void main(String args[]) throws FileNotFoundException, IOException {
		System.out.println("What is your name?");
		 Scanner keyboard = new Scanner(System.in);
		 username = keyboard.nextLine();
		User customer = new User(username);
		  ArrayList<String> listOfStrings
        = new ArrayList<String>();
   
    // load content of file based on specific delimiter
		 
     // load content of file based on specific delimiter
     Scanner sc = new Scanner(new FileReader("C:\\Users\\james\\Desktop\\Csi Work\\Testing\\src\\inv.txt"))
                      .useDelimiter(",\\s*");
     String str;
    
     // checking end of file
     while (sc.hasNextLine()) {
         str = sc.nextLine();
        
         // adding each string to arraylist
         listOfStrings.add(str);
     }
     

		
	
		for (int i = 0; i < listOfStrings.size(); i++)
			System.out.println(listOfStrings.get(i));
		
		//System.out.println(listOfStrings.size());
		
		  System.out.println("Your choice: ");
          
		  Scanner keyboard1 = new Scanner(System.in);
		  
		  choice= keyboard1.nextInt();
          
			if (choice < 0 || choice > listOfStrings.size()) {
              System.out.println("Try again between 1 and size");
          }  
			else  {
            	
            	
                System.out.print("Number of units: ");
                Scanner keyboard11 = new Scanner(System.in);
      		  
      		  totalUnits= keyboard11.nextInt();

		
		 
		 System.out.print("When do you plan to purchase? (mm/dd/yyyy) ");
		  Scanner keyboard111 = new Scanner(System.in);
  		  
  		 String purchaseDateString = keyboard111.nextLine();

		 //System.out.print(purchaseDateString);
		 
	 DateClass purchaseDate = new DateClass (purchaseDateString);
		 
		 boolean purchaseDatePromotion = purchaseDate.isPromotion();
		 //System.out.print(purchaseDatePromotion);
		 
		 String[] selection = listOfStrings.get(choice-1).split("\\|"); 
		 String productType = selection[3];
		 int productID = (Integer.valueOf(selection[0]));
		 char letter1=0;
		 switch (productType) 
         {
             case "Type X":
                 ProductX X = new ProductX(Integer.valueOf(selection[0]),selection[1],selection[3],totalUnits,Double.valueOf(selection[2]));
                 
                 
                 
             	Order order = new Order(customer, X, purchaseDate);
             
             	order.display();
             
                // int productID,String productName, String type, int amount,double price
                 
                 //X.display();
                 //System.out.println("Do you want to exit " +
                         //"the program (Y/N)?: ");
                 //Scanner keyboard99 = new Scanner(System.in);
				  break;
                 
		case "Type Y":
            	 ProductY Y = new ProductY(Integer.valueOf(selection[0]),selection[1],selection[3],totalUnits,Double.valueOf(selection[2]));
            	 Order order1 = new Order(customer, Y, purchaseDate);
                 
              	order1.display();
              
            	// int productID,String productName, String type, int amount,double price
                 break;
                 
             case "Type Z":
            	 ProductZ Z = new ProductZ(Integer.valueOf(selection[0]),selection[1],selection[3],totalUnits,Double.valueOf(selection[2]),purchaseDatePromotion);
            	 Order order3 = new Order(customer, Z, purchaseDate);
                 
              	order3.display();
              
            	 break;
              // int productID,String productName, String type, int amount,double price
				}
		 
         }

			// User class is created
			// Date class is created
			//Product Class is created
			//We know the number of units / date
			//We know the selection
			
	
		
		//if(type = X ) {
			
			
		//}
		}
	
		}