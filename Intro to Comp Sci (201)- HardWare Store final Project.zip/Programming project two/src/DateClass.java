import java.util.StringTokenizer;
public class DateClass {
	protected boolean Leapyear;
	protected int month;
	protected int day;
	protected int year;
	protected boolean isPromotion; 
	protected String date2;
	
	public DateClass(String Date) {
		this.date2=Date;
		
		String [] DateArray = Date.split("/");
		
		day = Integer.valueOf(DateArray[1]);
		
		month = Integer.valueOf(DateArray[0]);
		
		year = Integer.valueOf(DateArray[2]);
		
		if(DateArray.length!=3) {
		System.out.println("Error ");
			
		}
		
		//if(day31) {
			//System.out.println("Invalid choice for day");
			
		//}else(month>12) {
			//System.out.println("Invalid choice for month");
		//}
			
		//}else if (year % 4 ==0) {
    		//Leapyear=true;
			
		//}else {
    		//Leapyear=false;
    		//}
	}
	
	public boolean isPromotion(){
		//System.out.println(month);
		//System.out.println(day);
		if (month == 9) {
            if (day >=15) {
                return true;
            }
        } else if (month == 10) {
            if (day <= 14) {
                return true;
            }
        }
            return false;
		
		
	
	}
	}