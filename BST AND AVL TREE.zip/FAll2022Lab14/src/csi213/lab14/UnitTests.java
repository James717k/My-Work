package csi213.lab14;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.LinkedList;

import org.junit.Test;

import csi213.lab14.BinaryTree.Node;

/**
 * {@code UnitTests} tests the binary tree implementations.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 * 
 */
public class UnitTests {

	/**
	 * A sample {@code BinaryTree}.
	 */
	BinaryTree<String> left = new BinaryTree<String>("B", null, new BinaryTree<String>("D", null, null));

	/**
	 * A sample {@code BinaryTree}.
	 */
	BinaryTree<String> right = new BinaryTree<String>("C", new BinaryTree<String>("E", null, null),
			new BinaryTree<String>("F", new BinaryTree<String>("G", null, null), null));

	/**
	 * A sample {@code BinaryTree}.
	 */
	BinaryTree<String> t = new BinaryTree<String>("A", left, right);

	/**
	 * A sample sequence of integers.
	 */
	int[] elements1 = { 25, 13, 7, 19 };

	/**
	 * A sample sequence of integers.
	 */
	int[] elements2 = { 25, 13, 7, 19, 50, 30, 65, 51 };

	/**
	 * Tests {@link BinaryTree#preorder(Node node, PrintStream out)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test1() throws Exception {
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		t.preorder(out);
		out.println();
		left.preorder(out);
		out.println();
		right.preorder(out);
		out.println();
		assertArrayEquals(new String[] { "A B D C E F G ", "B D ", "C E F G " }, tOut.lines());
	}

	/**
	 * Tests {@link BinaryTree#inorder(Node node, PrintStream out)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test2() throws Exception {
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		t.inorder(out);
		out.println();
		left.inorder(out);
		out.println();
		right.inorder(out);
		out.println();
		assertArrayEquals(new String[] { "B D A E C G F ", "B D ", "E C G F " }, tOut.lines());
	}

	/**
	 * Tests {@link BinaryTree#postorder(Node node, PrintStream out)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test3() throws Exception {
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		t.postorder(out);
		out.println();
		left.postorder(out);
		out.println();
		right.postorder(out);
		out.println();
		assertArrayEquals(new String[] { "D B E G F C A ", "D B ", "E G F C " }, tOut.lines());
	}

	/**
	 * Tests {@code BinarySearchTree#add(E e, Node node)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void test4() throws Exception {
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		out.println(sampleBinarySearchTree1((BinaryTree<Integer>) Class
				.forName("csi213.lab14.BinarySearchTree").getConstructor().newInstance()));
		assertArrayEquals(new String[] { "25", " 13", "  7", "  19", " null", "" }, tOut.lines());
		out.close();

		tOut = new TextOutputStream();
		out = new PrintStream(tOut);
		out.println(sampleBinarySearchTree2((BinaryTree<Integer>) Class
				.forName("csi213.lab14.BinarySearchTree").getConstructor().newInstance()));
		assertArrayEquals(new String[] { "25", " 13", "  7", "  19", " 50", "  30", "  65", "   51", "   null", "" },
				tOut.lines());
		out.close();
	}

	/**
	 * Tests {@code BinarySearchTree#contains(E x, Node node)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void test5() throws Exception {
		BinaryTree<Integer> t = sampleBinarySearchTree1((BinaryTree<Integer>) Class
				.forName("csi213.lab14.BinarySearchTree").getConstructor().newInstance());
		assertEquals(false, contains(t, 0));
		assertEquals(false, contains(t, 50));
		assertEquals(false, contains(t, 100));
		for (int e : elements1)
			assertEquals(true, contains(t, e));

		t = sampleBinarySearchTree2((BinaryTree<Integer>) Class.forName("csi213.lab14.BinarySearchTree")
				.getConstructor().newInstance());
		assertEquals(false, contains(t, 0));
		assertEquals(true, contains(t, 50));
		assertEquals(false, contains(t, 100));
		for (int e : elements2)
			assertEquals(true, contains(t, e));
	}

	/**
	 * Tests {@code BinarySearchTree#remove(E e, Node node)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void test6() throws Exception {
		BinaryTree<Integer> t = sampleBinarySearchTree2((BinaryTree<Integer>) Class
				.forName("csi213.lab14.BinarySearchTree").getConstructor().newInstance());
		remove(t, 50);
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		out.println(t);
		out.close();
		assertArrayEquals(new String[] { "25", " 13", "  7", "  19", " 30", "  null", "  65", "   51", "   null", "" },
				tOut.lines());

		tOut = new TextOutputStream();
		out = new PrintStream(tOut);
		remove(t, 25);
		out.println(t);
		assertArrayEquals(
				new String[] { "19", " 13", "  7", "  null", " 30", "  null", "  65", "   51", "   null", "" },
				tOut.lines());
		out.close();

		tOut = new TextOutputStream();
		out = new PrintStream(tOut);
		remove(t, 30);
		out.println(t);
		assertArrayEquals(new String[] { "19", " 13", "  7", "  null", " 65", "  51", "  null", "" }, tOut.lines());
		out.close();
	}

	/**
	 * Tests {@code AVLTree#add(E e, Node node)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void test7() throws Exception {
		BinaryTree<Integer> t = (BinaryTree<Integer>) Class.forName("csi213.lab14.AVLTree").getConstructor()
				.newInstance();
		for (int e : new int[] { 0, 1, 2, 3, 4, 5, 6 })
			add(t, e);
		TextOutputStream tOut = new TextOutputStream();
		PrintStream out = new PrintStream(tOut);
		out.println(t);
		out.close();
		assertArrayEquals(new String[] { "3", " 1", "  0", "  2", " 5", "  4", "  6", "" }, tOut.lines());

		t = (BinaryTree<Integer>) Class.forName("csi213.lab14.AVLTree").getConstructor().newInstance();
		for (int e : new int[] { 6, 5, 4, 3, 2, 1, 0 })
			add(t, e);
		tOut = new TextOutputStream();
		out = new PrintStream(tOut);
		out.println(t);
		out.close();
		assertArrayEquals(new String[] { "3", " 1", "  0", "  2", " 5", "  4", "  6", "" }, tOut.lines());
	}

	/**
	 * Tests {@code BinarySearchTree#rangeIterator(E fromElement, E toElement)}.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void test8() throws Exception {
		BinaryTree<Integer> t = (BinaryTree<Integer>) Class.forName("csi213.lab14.BinarySearchTree")
				.getConstructor().newInstance();
		for (int e : new int[] { 25, 13, 7, 19, 50, 30, 65, 51 })
			add(t, e);

		Iterator<Integer> i = rangeIterator(t, 13, 51);
		String s = "";
		while (i.hasNext())
			s += i.next() + " ";
		assertEquals("13 19 25 30 50 ", s);

		i = rangeIterator(t, 13, 52);
		s = "";
		while (i.hasNext())
			s += i.next() + " ";
		assertEquals("13 19 25 30 50 51 ", s);

		i = rangeIterator(t, 13, 25);
		s = "";
		while (i.hasNext())
			s += i.next() + " ";
		assertEquals("13 19 ", s);

		i = rangeIterator(t, 26, 100);
		s = "";
		while (i.hasNext())
			s += i.next() + " ";
		assertEquals("30 50 51 65 ", s);
	}

	/**
	 * A {@code TextOutputStream} is an {@code OutputStream} to which text can be written and from which the written
	 * text can be obtained as an array of {@code String}s.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 *
	 */
	class TextOutputStream extends java.io.OutputStream {

		/**
		 * The {@code String}s representing the text that has been written to this {@code TextOutputStream}.
		 */
		LinkedList<String> buffer = new LinkedList<String>();

		/**
		 * The current line of text that has been written to this {@code TextOutputStream}.
		 */
		String current = "";

		@Override
		public void write(int b) throws IOException {
			if ((char) b == '\n') {
				buffer.add(current);
				current = "";
			} else if ((char) b != '\r')
				current += (char) b;
		}

		/**
		 * Returns an array of {@code String}s representing all the text that has been written to this
		 * {@code TextOutputStream}.
		 * 
		 * @return an array of {@code String}s representing all the text that has been written to this
		 *         {@code TextOutputStream}.
		 */
		public String[] lines() {
			return buffer.toArray(new String[0]);
		}

	}

	/**
	 * Obtains a sample {@code BinaryTree} by adding some elements to the specified {@code BinaryTree}.
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @return the sample {@code BinaryTree}
	 * @throws Exception
	 *             if an error occurs
	 */
	BinaryTree<Integer> sampleBinarySearchTree1(BinaryTree<Integer> t) throws Exception {
		for (int e : elements1)
			add(t, e);
		return t;
	}

	/**
	 * Obtains a sample {@code BinaryTree} by adding some elements to the specified {@code BinaryTree}.
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @return the sample {@code BinaryTree}
	 * @throws Exception
	 *             if an error occurs
	 */
	BinaryTree<Integer> sampleBinarySearchTree2(BinaryTree<Integer> t) throws Exception {
		for (int e : elements2)
			add(t, e);
		return t;
	}

	/**
	 * Adds the specified {@code Integer} to the specified {@code BinaryTree}.
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @param e
	 *            an {@code Integer}
	 * @throws Exception
	 *             if an error occurs
	 */
	void add(BinaryTree<Integer> t, Integer e) throws Exception {
		t.getClass().getMethod("add", Comparable.class).invoke(t, e);
	}

	/**
	 * Determines whether or not the specified {@code BinaryTree} contains the specified {@code Integer}.
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @param e
	 *            an {@code Integer}
	 * @return {@code true} if the specified {@code BinaryTree} contains the specified {@code Integer}; {@code false}
	 *         otherwise
	 * @throws Exception
	 *             if an error occurs
	 */
	boolean contains(BinaryTree<Integer> t, Integer e) throws Exception {
		return (boolean) t.getClass().getMethod("contains", Comparable.class).invoke(t, e);
	}

	/**
	 * Removes the specified {@code Integer} from the specified {@code BinaryTree}.
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @param e
	 *            an {@code Integer}
	 * @throws Exception
	 *             if an error occurs
	 */
	void remove(BinaryTree<Integer> t, Integer e) throws Exception {
		t.getClass().getMethod("remove", Comparable.class).invoke(t, e);
	}

	/**
	 * Returns an {@code Iterator} from the specified {@code BinaryTree} over the elements that range from
	 * {@code fromElement} (inclusive) to {@code toElement} (exclusive).
	 * 
	 * @param t
	 *            a {@code BinaryTree}
	 * @param fromElement
	 *            low endpoint (inclusive) of the range
	 * @param toElement
	 *            high endpoint (exclusive) of the range
	 * @return an {@code Iterator} the specified {@code BinaryTree} over the elements that range from
	 *         {@code fromElement} (inclusive) to {@code toElement} (exclusive)
	 * @throws Exception
	 *             if an error occurs
	 */
	@SuppressWarnings("unchecked")
	Iterator<Integer> rangeIterator(BinaryTree<Integer> t, Integer fromElement, Integer toElement) throws Exception {
		return (Iterator<Integer>) t.getClass().getMethod("rangeIterator", Comparable.class, Comparable.class).invoke(t,
				fromElement, toElement);
	}



}