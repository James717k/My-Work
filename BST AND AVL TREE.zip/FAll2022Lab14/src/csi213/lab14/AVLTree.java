package csi213.lab14;
/**
 * 
 * @author james krueger
 * This creates an AVL Tree that extends the BinarySearchTree. 
 * The difference between an AVL and BinaryTree is that an AVL Tree has to keep an balance.
 * In this file you will see that we create a new AVL node so we do not have a type error.
 * Then you would see all the methods from BST.
 * Furthermore you will see new methods that are specific to an AVL Tree.
 * To be specific the balance methods which keeps the AVL Tree an AVL Tree and height methods which track the height of the trees. 
 * @param <E> type of our elements
 */
public class AVLTree<E extends Comparable<E>> extends BinarySearchTree<E> {
	
	
	@Override
	Node createNode(E element, Node left, Node right) {
	return new AVLNode(element, left, right);
	}
	/**
	 * 
	 * This AVL node called the method from BinarySearchTree
	 * @param height stores the height of each tree. 
	 * @param element is our elements.
	 * @param left is the left node
	 * @param is the right node. 
	 *
	 */
	class AVLNode extends Node {
		int height;

	public AVLNode(E element, Node left, Node right) {
		super(element, left, right);
		height = 0;
	}
/**
 * This @resetHeight allows for the AVL Tree to reset the height of each sub tree.
 * @param leftHeight is the height of the whole left subtree
 * @param rightHeigth is the height of the whole of the right subtree
 */
	public void resetHeight() {
		int leftHeight = getHeight(left);
		int rightHeight = getHeight(right);
		height = 1 + Math.max(leftHeight, rightHeight);
	}
	}
	/**
	 * 
	 * @param node creates a node for an element
	 * @return returns the height of the node. 
	 */
	
	@SuppressWarnings("unchecked")
	int getHeight(Node node) {
		if (node == null)
			return -1;
		return ((AVLNode) node).height;
	}
	
	/**
	 * This method creates a way for us to add elements to the avl tree. 
	 * @param e is our elements
	 * @param node creates a node for an element
	 * @return called the method of balance if needed.
	 */
	@Override
	Node add(E e, Node node) {
	node = super.add(e, node);
	return balanceIfNecessary(node);
	}
	
	/**
	 * This method removes a node if needed.
	 * @param e is our elements 
	 * @param node creates a node for elements. 
	 */
	@Override
	Node remove(E e, Node node) {
	node = super.remove(e, node);
	return balanceIfNecessary(node);
	}
	
	/**
	 * This method checks for any inbalance within in the tree
	 * 
	 * @param node creates a AVL node to store elements
	 * @param leftHeight is the height of the left tree.
	 * @param rightHeight is the height of the right tree
	 * @return returns if it is unbalance or not. 
	 *@param    leftChild is the child of the left subtree
	* @param rightChild is the child of the right subtree
	 *@param llHeight is the height of the left sub tree left child
	 * @param lrHeight is the height of the left sub tree right child. 
	 * @param llBalance is the method being called to fix an left heavy inbalance
	 * @param lrBalance is the method being called to fix an left-right heavy inbalance
	 * @param rrHeight is the height of the right sub tree right child
	 * @param rlHeight is the height of the right sub tree left child
	 @param rrBalance is the method being called to fix a right heavy inbalance
	 @param rlBalance is the method being called to fix a right-left heavy inbalance
	 */
	
	Node balance(AVLNode node, int leftHeight, int rightHeight) {
		if (leftHeight > rightHeight) { // if left-heavy
		Node leftChild = node.left;
		int llHeight = getHeight(leftChild.left);
		int lrHeight = getHeight(leftChild.right);
		if (llHeight > lrHeight) // if ll unbalanced
		return llBalance(node);
		else // if lr unbalanced
		return lrBalance(node);
		} else { // if right-heavy
		Node rightChild = node.right;
		int rrHeight = getHeight(rightChild.right);
		int rlHeight = getHeight(rightChild.left);
		if (rrHeight > rlHeight) // if rr unbalanced
		return rrBalance(node);
		else // if rl unbalanced
		return rlBalance(node);
		}
		}
	
	/**
	 * This code fixed a Left-Left imbalance meaning the tree is left heavy.
	 * @param node creates a AVL node for elements
	 * @return returns the left node
	 * @param lNode is the left node of the left subtree
	 * @param lrNode is the left sub tree right node
	 */
	Node llBalance(AVLNode node) {
		AVLNode lNode = (AVLNode) node.left;
		AVLNode lrNode = (AVLNode) lNode.right;
		lNode.right = node;
		node.left = lrNode;
		node.resetHeight();
		lNode.resetHeight();
		return lNode;
		}
	
	
	/**
	 * This code fixed a Right-Right imbalance meaning the tree is right heavy.
	 * @param node creates a AVL node for elements
	 * @return the right node
	 *  * @param RNode is the right node of the right subtree
	 * @param rrNode is the right sub tree right node
	 */
	Node rrBalance(AVLNode node) {
		AVLNode rNode = (AVLNode) node.right;
		AVLNode rlNode = (AVLNode) rNode.left;
		rNode.left = node;
		node.right = rlNode;
		node.resetHeight();
		rNode.resetHeight();
		return rNode;
		}
	
	
	/**
	 * 
	 * @param node creates a AVL node.
	 * @return the left subtree right node. 
	 * @param root is the grandparent
	 * @param lrlTree is a node that stores the left sub tree left child to the left node
	 * @param lrrTree is a node that stores the left sub tree right child node to the right node
	 */
	@SuppressWarnings("unchecked")
	Node lrBalance(AVLNode node) {
	AVLNode root = node;
	AVLNode lNode = (AVLNode) root.left;
	AVLNode lrNode = (AVLNode) lNode.right;
	AVLNode lrlTree = (AVLNode) lrNode.left;
	AVLNode lrrTree = (AVLNode) lrNode.right;
	lNode.right = lrlTree;
	root.left = lrrTree;
	lrNode.left = lNode;
	lrNode.right = root;
	lNode.resetHeight();
	root.resetHeight();
	lrNode.resetHeight();
	return lrNode;
	}
	
	/**
	 * This method checks for a right-left heavy balance
	 * @param node creates a AVL node.
	 * @return the right sub tree left child
	 * @param root is the grandparent
	 * @param rNode is the right node
	 * @param rlNode is the right node left child
	 * @param rlrTree is the right subtree left node right child 
	 * @param rllTree is the right subtree left node left child
	 */
	
	@SuppressWarnings("unchecked")
	Node rlBalance(AVLNode node) {
	AVLNode root = node;
	AVLNode rNode = (AVLNode) root.right;
	AVLNode rlNode = (AVLNode) rNode.left;
	AVLNode rlrTree = (AVLNode) rlNode.right;
	AVLNode rllTree = (AVLNode) rlNode.left;
	rNode.left = rlrTree;
	root.right = rllTree;
	rlNode.left = root;
	rlNode.right = rNode;
	rNode.resetHeight();
	root.resetHeight();
	rlNode.resetHeight();
	return rlNode;
	}
	/**
	 * 
	 * @param node creates a AVL node
	 * @return node
	 * returns a node
	 * @return balance calls the method of balance.
	 * @param leftHei is the height of the left sub tree left child
	 * @param lrHeight is the height of the left sub tree right child. 
	 */
	
	Node balanceIfNecessary(Node node) {
		if (node == null) // if the subtree rooted at node is empty
		return node;
		int leftHeight = getHeight(node.left); // height of left subtree
		int rightHeight = getHeight(node.right); // height of right subtree
		if (Math.abs(leftHeight - rightHeight) == 2) { // if unbalanced
		return balance((AVLNode) node, leftHeight, rightHeight);
		} else { // if balanced
		((AVLNode) node).resetHeight();
		return node;
		}
		}
	
	/**
	 * The main method of the {@code AVL Tree} class.
	 * 
	 * @param args
	 *            the program arguments
	 * @throws Exception
	 *             if an error occurs
	 */
	
	public static void main(String[] args) throws Exception{
		AVLTree<Integer> t = new AVLTree<Integer>();
		for (int e : new int[] { 0, 1, 2, 3, 4, 5, 6 }) {
			t.add(e);
			System.out.println(t);
			t = new AVLTree<Integer>();
			for (int e1 : new int[] { 6, 5, 4, 3, 2, 1, 0 }) {
				t.add(e1);
				System.out.println(t);
			}
		}
	}
	
}