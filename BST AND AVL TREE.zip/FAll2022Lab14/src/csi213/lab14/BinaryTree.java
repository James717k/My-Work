package csi213.lab14;

import java.io.PrintStream;

/**
 * A {@code BinaryTree} consists of {@code Node}s each with at most one parent {@code Node} and up to two child
 * {@code Node}s. A non-empty {@code BinaryTree} has only one single {@code Node}, called the root {@code Node}, which
 * has no parent {@code Node}.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 *
 * @param <E>
 *            the type of elements
 */
public class BinaryTree<E> {
	

	/**
	 * A {@code Node} in a {@code BinaryTree} holds an element, a link to the left child {@code Node} if exists, and a
	 * link to the right child {@code Node} if exists.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 */
	class Node {

		/**
		 * The element that this {@code Node} holds.
		 */
		E element;

		/**
		 * The left child {@code Node} of this {@code Node}.
		 */
		Node left;

		/**
		 * The right child {@code Node} of this {@code Node}.
		 */
		Node right;

		/**
		 * Constructs a {@code Node}.
		 * 
		 * @param element
		 *            the element that the {@code Node} needs to hold
		 * @param left
		 *            the left child {@code Node} of the new {@code Node}
		 * @param right
		 *            the right child {@code Node} of the new {@code Node}
		 */
		public Node(E element, Node left, Node right) {
			this.element = element;
			this.left = left;
			this.right = right;
		}
	}
	

	/**
	 * Constructs a new {@code Node}.
	 * 
	 * @param element
	 *            the element that the {@code Node} needs to hold
	 * @param left
	 *            the left child {@code Node} of the new {@code Node}
	 * @param right
	 *            the right child {@code Node} of the new {@code Node}
	 * @return the new {@code Node}
	 */
	Node createNode(E element, Node left, Node right) {
		return new Node(element, left, right);
	}

	/**
	 * The root {@code Node} of this {@code BinaryTree}.
	 */
	Node root = null;

	/**
	 * Constructs an empty {@code BinaryTree}.
	 */
	public BinaryTree() {
		root = null;
	}

	/**
	 * Prints the elements of this {@code BinaryTree} while visiting the root first, and then recursively the left and
	 * right subtrees.
	 * 
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void preorder(PrintStream out) {
		preorder(root, out);
	}

	/**
	 * Prints the elements in the subtree rooted at the specified {@code Node} while visiting that {@code Node} first,
	 * and then recursively its left and right subtrees.
	 * 
	 * @param node
	 *            a {@code Node}
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void preorder(Node node, PrintStream out) {
		// TODO: add some code here
		if (node != null) {
			out.print(node.element + " ");
			preorder(node.left, out);
			preorder(node.right, out);
			}
	}

	/**
	 * Prints the elements of this {@code BinaryTree} while recursively visiting the left subtree, the root, and then
	 * the right subtree.
	 * 
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void inorder(PrintStream out) {
		inorder(root, out);
	}

	/**
	 * Prints the elements in the subtree rooted at the specified {@code Node} while recursively visiting the left
	 * subtree, the {@code Node}, and then the right subtree.
	 * 
	 * @param node
	 *            a {@code Node}
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void inorder(Node node, PrintStream out) {
		// TODO: add some code here
		if (node != null) {
			inorder(node.left, out);
			out.print(node.element + " ");
			inorder(node.right, out);
			}
	}

	/**
	 * Prints the elements of this {@code BinaryTree} while recursively visiting the left subtree, the root, and then
	 * the right subtree.
	 * 
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void postorder(PrintStream out) {
		postorder(root, out);
	}

	/**
	 * Prints the elements in the subtree rooted at the specified {@code Node} while recursively visiting the left and
	 * right subtrees, and then the {@code Node}.
	 * 
	 * @param node
	 *            a {@code Node}
	 * @param out
	 *            a {@code PrintStream} to which the elements are printed
	 */
	public void postorder(Node node, PrintStream out) {
		// TODO: add some code here
		if (node != null) {
			postorder(node.left, out);
			postorder(node.right, out);
			out.print(node.element + " ");
			}
	}

	/**
	 * Returns a string representation of this {@code BinaryTree}.
	 * 
	 * @return a string representation of this {@code BinaryTree}
	 */
	@Override
	public String toString() {
		return toString(root, 0);
	}

	/**
	 * Constructs a new {@code BinaryTree} that contains the specified element at its root {@code Node} and has the
	 * specified {@code BinaryTree}s as its left and right subtrees.
	 * 
	 * @param element
	 *            an element to store at the root {@code Node} of the {@code BinaryTree}
	 * @param left
	 *            the left subtree of the new {@code BinaryTree}
	 * @param right
	 *            the right subtree of the new {@code BinaryTree}
	 */
	public BinaryTree(E element, BinaryTree<E> left, BinaryTree<E> right) {
		root = createNode(element, left == null ? null : left.root, right == null ? null : right.root);
	}

	/**
	 * Returns a string representation of the subtree rooted at the specified {@code Node}.
	 * 
	 * @param node
	 *            a {@code Node}
	 * @param indentation
	 *            the number of space characters to include
	 * @return a string representation of the subtree rooted at the specified {@code Node}
	 */
	String toString(Node node, int indentation) {
		if (node == null)
			return space(indentation) + "null" + System.lineSeparator();
		else {
			if (node.left == null && node.right == null)
				return space(indentation) + node.element + System.lineSeparator();
			else
				return space(indentation) + node.element + System.lineSeparator() + toString(node.left, indentation + 1)
						+ toString(node.right, indentation + 1);
		}
	}

	/**
	 * Returns a string containing the specified number of space characters.
	 * 
	 * @param length
	 *            the number of space characters
	 * @return a string containing the specified number of space characters
	 */

	String space(int length) {
		String s = "";
		for (int i = 0; i < length; i++)
			s += " ";
		return s;
	}

	/**
	 * The main method of the {@code BinaryTree} class.
	 * 
	 * @param args
	 *            the program arguments
	 * @throws Exception
	 *             if an error occurs
	 */
	public static void main(String[] args) throws Exception {
		BinaryTree<String> left = new BinaryTree<String>("B", null, new BinaryTree<String>("D", null, null));
		BinaryTree<String> right = new BinaryTree<String>("C", new BinaryTree<String>("E", null, null),
				new BinaryTree<String>("F", new BinaryTree<String>("G", null, null), null));
		BinaryTree<String> t = new BinaryTree<String>("A", left, right);
		System.out.println(t);

		t.preorder(System.out);
		System.out.println();

		t.inorder(System.out);
		System.out.println();

		t.postorder(System.out);
		System.out.println();
	}

}
