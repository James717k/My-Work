package csi213.lab14;

import java.util.Iterator;
/**
 * 
 * @author James Krueger
 * This code is a BinarySearchTree with elements of type E that extends to Binary Tree.
 * We have our @add method that adds an element to the Binary Tree.
 * We have our @contains method that checks if our Binary Tree has a element.
 * We our the @remove method that checks for the element to remove and removes it.
 * Our @max method checks for the max node and replaces it with another node if max is called within our remove method
 * Each node class allows for a node to be created for each method so we can actually have a tree structure.
 * 
 * @param <E> is the type our elements 
 */
public class BinarySearchTree<E extends Comparable<E>> extends BinaryTree<E>{
	/**
	 * 
	 * @param e
	 * 	is our elements. 
	 */
	
	public void add(E e) {
		root = add(e, root);
	}
	/**
	 * 
	 * @param e is our elements
	 * @param node is a node that can store elements 
	 * @return the node 
	 * @param c is being set to a compare function
	 */
	Node add(E e, Node node) {
		if (node == null)
		return createNode(e, null, null);
		int c = e.compareTo(node.element);
		if (c < 0) // if e < node.element
		node.left = add(e, node.left);
		else if (c > 0) // if e > node.element
		node.right = add(e, node.right);
		return node;
		}
	

	/**
	 * This code allows us to define the method contains and be able to use it. 
	 * @param x is our elements
	 * @return calls the method contain to see if the element is there.
	 */
	public boolean contains(E x) {
		return contains(x, root);
		
	}
	
	/**
	 * This method allows us to check if there is an element there.
	 * @param x is our element
	 * @param node is a node that can store elements 
	 * @return calls the method contain to see if x is there.
	 */
	boolean contains(E x, Node node) {
		if (node == null)
		return false;
		int c = x.compareTo(node.element);
		if (c == 0) // if x == node.element
		return true;
		if (c < 0) // if x < node.element
		return contains(x, node.left);
		else // if x > node.element
		return contains(x, node.right);
		}
	
	/**
	 * 
	 * @param e is our elements 
	 */
	public void remove(E e) {
		root = remove(e, root);
		}
	/**
	 * This method 
	 * 	allows us to search through the tree and remove certian elements.
	 * @param e is our elements
	 * @param node allows for elements to be in a node
	 * @return returns the node that we are at. 
	 * @param c is being set to a compare function
	 */
		Node remove(E e, Node node) {
		if (node == null) // if the current subtree is empty
		return node;
		int c = e.compareTo(node.element);
		if (c < 0) // if e < node.element
		node.left = remove(e, node.left); // removal in the left subtree
		else if (c > 0) // if e > node.element
		node.right = remove(e, node.right); // removal in the right subtree
		else { // the current node needs to be removed
		if (node.left == null) // if node has only one child or no child
		return node.right; // remove it if no child; otherwise, replace it with the child
		else if (node.right == null) // if node has only one child
		return node.left; // replace it with the child
		// if node with two children: replace it with the largest in the left subtree
		node.element = max(node.left);
		node.left = remove(node.element, node.left); // remove the largest in the left subtree
		}
		return node;
		}
		
		
		
/**
 * 		This method allows us to search for a node with two children
 * 		to replace it with the largest in the left subtree
 * @param node is a node with something inside it.
 * @param node is being stored to the right node. 
 * @return returns the element in the node. 
 */
    public E max(Node node) {

 

        while(node.right != null)
        {
             node=node.right;
        }


        return node.element;
    }
    
    
   
    /**
	 * The main method of the {@code BinarySearchTree} class.
	 * 
	 * @param args
	 *            the program arguments
	 * @throws Exception
	 *             if an error occurs
	 */
		public static void main(String[] args) throws Exception{
	
		BinarySearchTree<Integer> t = new BinarySearchTree<Integer>();
		
		t.add(25);
		
		System.out.println(t);
		
		t.add(13);
		
		System.out.println(t);
		
		t.add(7);
		
		System.out.println(t);
		
		t.add(19);
		
		System.out.println(t);
		
		

		t = new BinarySearchTree<Integer>();
		for (int e : new int[] { 25, 13, 7, 19, 50, 30, 65, 51 })
			
			t.add(e);
		
		System.out.println(t.contains(0));
		
		System.out.println(t.contains(7));
		
		System.out.println(t.contains(50));
		
		System.out.println(t.contains(60));
		
		System.out.println(t.contains(65));
		
		System.out.println(t.contains(100));
		
		System.out.println(t);
		
		t.remove(50);
		
		System.out.println(t);
		
		t.remove(25);
		
		System.out.println(t);
		
		t.remove(30);
		
		
	}
}
