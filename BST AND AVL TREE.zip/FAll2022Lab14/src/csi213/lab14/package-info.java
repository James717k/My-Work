/**
 * Provides binary tree implementations.
 */
package csi213.lab14;