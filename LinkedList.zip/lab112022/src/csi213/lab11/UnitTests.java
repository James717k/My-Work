package csi213.lab11;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Iterator;

import org.junit.Test;

/**
 * {@code UnitTests} tests the Lab 11 implementations.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 * 
 */
public class UnitTests {

	/**
	 * Tests the Task 1 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test1() throws Exception {
		List<String> l = new LinkedList<String>();
		assertEquals(0, l.size());
		assertEquals("()", "" + l);

		l.add("1");
		assertEquals(1, l.size());
		assertEquals("(1)", "" + l);

		l.add("2");
		assertEquals(2, l.size());
		assertEquals("(1, 2)", "" + l);
	}

	/**
	 * Tests the Task 2 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test2() throws Exception {
		List<String> l = createList();
		assertEquals("1", l.get(0));
		assertEquals("2", l.get(1));
		Object o = null;
		try {
			o = l.get(2);
		} catch (Exception e) {
			o = e;
		}
		assertTrue(o instanceof IndexOutOfBoundsException);
		l.add("3");
		assertEquals("3", l.get(2));
	}

	/**
	 * Tests the Task 3 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test3() throws Exception {
		List<String> l = createList();
		l.add(0, "0");
		assertEquals("(0, 1, 2)", "" + l);
		l.add(3, "3");
		assertEquals("(0, 1, 2, 3)", "" + l);
		Object o = null;
		try {
			l.add(5, "5");
		} catch (Exception e) {
			o = e;
		}
		assertTrue(o instanceof IndexOutOfBoundsException);
	}

	/**
	 * Tests the Task 4 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test4() throws Exception {
		List<String> l = createList();
		l.add(0, "0");
		l.add(3, "3");
		l.remove(3);
		assertEquals("(0, 1, 2)", "" + l);
		l.remove(0);
		assertEquals("(1, 2)", "" + l);
		Object o = null;
		try {
			l.remove(3);
		} catch (Exception e) {
			o = e;
		}
		assertTrue(o instanceof IndexOutOfBoundsException);
	}

	/**
	 * Tests the Task 5 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test5() throws Exception {
		List<String> l = createList();
		assertEquals("(1, 2)", toString(l.iterator()));
		l.add(0, "0");
		assertEquals("(0, 1, 2)", toString(l.iterator()));
		l.add(3, "3");
		assertEquals("(0, 1, 2, 3)", toString(l.iterator()));
	}

	/**
	 * Constructs a {@code List} containing "1" and "2".
	 * 
	 * @return a {@code List} containing "1" and "2"
	 */
	protected List<String> createList() {
		LinkedList<String> l = new LinkedList<String>();
		l.add("1");
		l.add("2");
		return l;
	}

	/**
	 * Returns a string representing the values that can be accessed using the specified {@code Iterator}.
	 * 
	 * @param i
	 *            an {@code Iterator}
	 * @return a string representing the values that can be accessed using the specified {@code Iterator}
	 */
	public static String toString(Iterator<String> i) {
		String s = "(";
		while (i.hasNext())
			s += i.next() + (i.hasNext() ? ", " : "");
		return s + ")";
	}

}
