
public class ContinueNode  extends StatementNode {
    public ContinueNode(int lineNumber, int charPosition) {
		super(lineNumber, charPosition);
	}

	
    public String toString() {
        return "Continue";
    }
}
