
public class BreakNode extends StatementNode {
    public BreakNode(int lineNumber, int charPosition) {
    	 super(lineNumber, charPosition);
    }

    
    public String toString() {
        return "Break";
    }

}
