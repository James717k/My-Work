# AWK-Complier
- Can read files written in AWK, its input data, and output the corresponding results.
- This Project was done for ICSI-311 Principles of Programming Languages at the University at Albany.
- These files have a majority of the code:
- Lexer
- Parser
- Interpreter
- The other files are used to help these 3 main files
