package csi213.projects.sort;

import java.io.PrintStream;
import java.util.Arrays;

/**
 * A {@code BubbleSort} instance runs the bubble sort algorithm on the array given to it when it is being constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class BubbleSort extends Sort {

	/**
	 * Constructs a {@code BubbleSort} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public BubbleSort(int[] a, PrintStream out) {
		super(a, out);
	}

	/**
	 * Sorts the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	protected void sort(int[] a, PrintStream out) {
		for (int last = a.length - 1; last >= 1; last--) {
			// TODO: add some code here
			 for (int index = 0; index <= last-1; index++,numberOfComparisons++) {
			
				 if(a[index]> a[index+1] ) {
					 int temp = a[index];	 numberOfArrayElementUpdates++;
					 a[index] = a[index+1];	 numberOfArrayElementUpdates++;
					 a[index+1]=  temp;	 
				 }
			 }
			if (out != null) // do NOT delete this statement
				out.println(Arrays.toString(a));
		}
	}

	/**
	 * The main method of the {@code BubbleSort} class.
	 * 
	 * @param args
	 *            the program arguments
	 */
	public static void main(String[] args) {
		int[] a = { 5, 3, 1, 2, 4 };
		BubbleSort s = new BubbleSort(a, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
		System.out.println();

		int[] b = { 7, 6, 5, 1, 2, 3, 4 };
		s = new BubbleSort(b, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
	}

}
