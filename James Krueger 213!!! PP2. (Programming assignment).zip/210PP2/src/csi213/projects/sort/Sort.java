package csi213.projects.sort;

import java.io.PrintStream;

/**
 * A {@code Sort} instance sorts the array given to it when it is being constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public abstract class Sort {

	/**
	 * The time (in nanoseconds) when sorting started.
	 */
	long startTime;

	/**
	 * The time (in nanoseconds) when sorting completed.
	 */
	long completionTime;

	/**
	 * The number of comparisons performed during sorting.
	 */
	long numberOfComparisons = 0;

	/**
	 * The number of array element updates performed during sorting.
	 */
	long numberOfArrayElementUpdates = 0;

	/**
	 * Constructs a {@code Sort} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public Sort(int[] a, PrintStream out) {
		startTime = System.nanoTime();
		sort(a, out);
		completionTime = System.nanoTime();
	}

	/**
	 * Sorts the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	abstract protected void sort(int[] a, PrintStream out);

	/**
	 * Returns the time (in nanoseconds) spent for sorting the array when this {@code Sort} was instantiated.
	 * 
	 * @return the time (in nanoseconds) spent for sorting the array when this {@code Sort} was instantiated.
	 */
	public long duration() {
		return completionTime - startTime;
	}

	/**
	 * Returns the number of comparisons performed during sorting.
	 * 
	 * @return the number of comparisons performed during sorting
	 */
	public long numberOfComparisons() {
		return numberOfComparisons;
	}

	/**
	 * Returns the number of array element updates performed during sorting.
	 * 
	 * @return the number of array element updates performed during sorting
	 */
	public long numberOfArrayElementUpdates() {
		return numberOfArrayElementUpdates;
	}

}
