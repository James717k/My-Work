package csi213.projects.sort;

import java.io.PrintStream;
import java.util.Arrays;

/**
 * A {@code SelectionSort} instance runs the selection sort algorithm on the array given to it when it is being
 * constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class SelectionSort extends Sort {

	/**
	 * Constructs a {@code SelectionSort} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public SelectionSort(int[] a, PrintStream out) {
		super(a, out);
	}

	/**
	 * Sorts the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	protected void sort(int[] a, PrintStream out) {
		for (int last = a.length - 1; last >= 1; last--) {
			// TODO: add some code here
			int maxIndex =0;
			for(int index=1; index<= last;index++, numberOfComparisons++) {
			if(a[index]>a[maxIndex]) {
				maxIndex = index; 
			}
			}
			int temp = a[maxIndex]; numberOfArrayElementUpdates++;
			a[maxIndex]= a[last];  numberOfArrayElementUpdates++;
			a[last]=temp;
			if (out != null) // do NOT delete this statement
				out.println(Arrays.toString(a));
		}
		
	}

	/**
	 * The main method of the {@code SelectionSort} class.
	 * 
	 * @param args
	 *            the program arguments
	 */
	public static void main(String[] args) {
		int[] a = { 5, 3, 1, 2, 4 };
		SelectionSort s = new SelectionSort(a, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
		System.out.println();

		int[] b = { 7, 6, 5, 1, 2, 3, 4 };
		s = new SelectionSort(b, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
	}

}
