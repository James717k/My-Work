package csi213.projects.sort;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Random;

import org.junit.Test;

/**
 * {@code UnitTests} tests sorting algorithm implementations.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 * 
 */
public class UnitTests {

	/**
	 * An array for testing sorting algorithm implementations.
	 */
	static int[] a = { 5, 3, 1, 2, 4 };

	/**
	 * An array for testing sorting algorithm implementations.
	 */
	static int[] b = { 7, 6, 5, 1, 2, 3, 4 };

	/**
	 * An array representing the desired results from sorting algorithm implementations.
	 */
	static String[][] resultA = { { "[3, 1, 2, 4, 5]", "[1, 2, 3, 4, 5]", "[1, 2, 3, 4, 5]", "[1, 2, 3, 4, 5]" },

			{ "[4, 3, 1, 2, 5]", "[2, 3, 1, 4, 5]", "[2, 1, 3, 4, 5]", "[1, 2, 3, 4, 5]" },

			{ "[3, 5, 1, 2, 4]", "[1, 3, 5, 2, 4]", "[1, 2, 3, 5, 4]", "[1, 2, 3, 4, 5]" },

			{ "[4, 3, 1, 2, 5]", "[2, 3, 1, 4, 5]", "[1, 2, 3, 4, 5]" } };

	/**
	 * An array representing the desired results from sorting algorithm implementations.
	 */
	static String[][] resultB = {
			{ "[6, 5, 1, 2, 3, 4, 7]", "[5, 1, 2, 3, 4, 6, 7]", "[1, 2, 3, 4, 5, 6, 7]", "[1, 2, 3, 4, 5, 6, 7]",
					"[1, 2, 3, 4, 5, 6, 7]", "[1, 2, 3, 4, 5, 6, 7]" },

			{ "[4, 6, 5, 1, 2, 3, 7]", "[4, 3, 5, 1, 2, 6, 7]", "[4, 3, 2, 1, 5, 6, 7]", "[1, 3, 2, 4, 5, 6, 7]",
					"[1, 2, 3, 4, 5, 6, 7]", "[1, 2, 3, 4, 5, 6, 7]" },

			{ "[6, 7, 5, 1, 2, 3, 4]", "[5, 6, 7, 1, 2, 3, 4]", "[1, 5, 6, 7, 2, 3, 4]", "[1, 2, 5, 6, 7, 3, 4]",
					"[1, 2, 3, 5, 6, 7, 4]", "[1, 2, 3, 4, 5, 6, 7]" },

			{ "[4, 6, 5, 1, 2, 3, 7]", "[3, 1, 2, 4, 5, 6, 7]", "[2, 1, 3, 4, 5, 6, 7]", "[1, 2, 3, 4, 5, 6, 7]",
					"[1, 2, 3, 4, 5, 6, 7]" } };

	/**
	 * Tests the Task 1 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test1a() throws Exception {
		TextOutputStream out = new TextOutputStream();
		new BubbleSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertArrayEquals(resultA[0], out.lines());

		out = new TextOutputStream();
		new BubbleSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertArrayEquals(resultB[0], out.lines());
	}

	/**
	 * Tests the Task 1 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test1b() throws Exception {
		TextOutputStream out = new TextOutputStream();
		BubbleSort s = new BubbleSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertEquals(10, s.numberOfComparisons());
		assertEquals(12, s.numberOfArrayElementUpdates());

		out = new TextOutputStream();
		s = new BubbleSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertEquals(21, s.numberOfComparisons());
		assertEquals(30, s.numberOfArrayElementUpdates());
	}

	/**
	 * Tests the Task 2 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test2a() throws Exception {
		TextOutputStream out = new TextOutputStream();
		new SelectionSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertArrayEquals(resultA[1], out.lines());

		out = new TextOutputStream();
		new SelectionSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertArrayEquals(resultB[1], out.lines());
	}

	/**
	 * Tests the Task 2 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test2b() throws Exception {
		TextOutputStream out = new TextOutputStream();
		SelectionSort s = new SelectionSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertEquals(10, s.numberOfComparisons());
		assertEquals(8, s.numberOfArrayElementUpdates());

		out = new TextOutputStream();
		s = new SelectionSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertEquals(21, s.numberOfComparisons());
		assertEquals(12, s.numberOfArrayElementUpdates());
	}

	/**
	 * Tests the Task 3 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test3a() throws Exception {
		TextOutputStream out = new TextOutputStream();
		new InsertionSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertArrayEquals(resultA[2], out.lines());

		out = new TextOutputStream();
		new InsertionSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertArrayEquals(resultB[2], out.lines());
	}

	/**
	 * Tests the Task 3 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test3b() throws Exception {
		TextOutputStream out = new TextOutputStream();
		InsertionSort s = new InsertionSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertEquals(8, s.numberOfComparisons());
		assertEquals(10, s.numberOfArrayElementUpdates());

		out = new TextOutputStream();
		s = new InsertionSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertEquals(18, s.numberOfComparisons());
		assertEquals(21, s.numberOfArrayElementUpdates());
	}

	/**
	 * Tests the Task 4 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test4a() throws Exception {
		TextOutputStream out = new TextOutputStream();
		new QuickSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertArrayEquals(resultA[3], out.lines());

		out = new TextOutputStream();
		new QuickSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertArrayEquals(resultB[3], out.lines());
	}

	/**
	 * Tests the Task 4 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test4b() throws Exception {
		TextOutputStream out = new TextOutputStream();
		QuickSort s = new QuickSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertEquals(9, s.numberOfComparisons());
		assertEquals(22, s.numberOfArrayElementUpdates());

		out = new TextOutputStream();
		s = new QuickSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertEquals(15, s.numberOfComparisons());
		assertEquals(34, s.numberOfArrayElementUpdates());
	}

	/**
	 * Tests the Task 4 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test4c() throws Exception {
		TextOutputStream out = new TextOutputStream();
		QuickSort s = new QuickSort(Arrays.copyOf(a, a.length), new java.io.PrintStream(out));
		assertEquals(7, s.numberOfRecursiveInvocations());
		assertEquals(4, s.maximumDepthOfRecursion());

		out = new TextOutputStream();
		s = new QuickSort(Arrays.copyOf(b, b.length), new java.io.PrintStream(out));
		assertEquals(11, s.numberOfRecursiveInvocations());
		assertEquals(5, s.maximumDepthOfRecursion());
	}

	/**
	 * Tests the Task 5 implementation.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void test5() throws Exception {
		for (int size = 10; size <= 100000; size *= 10) {
			int[] a = QuickSortImproved.createSortedArray(size);
			int[] b = QuickSortImproved.shuffle(a, new Random(0));
			new QuickSortImproved(b, null);
			assertArrayEquals(a, b);
		}
		for (int size = 10; size <= 100000; size *= 10) {
			int[] a = QuickSortImproved.createSortedArray(size);
			int[] b = Arrays.copyOf(a, size);
			new QuickSortImproved(b, null);
			assertArrayEquals(a, b);
		}
		for (int size = 10; size <= 100000; size *= 10) {
			int[] a = new int[size];
			int[] b = Arrays.copyOf(a, size);
			new QuickSortImproved(b, null);
			assertArrayEquals(a, b);
		}
	}

	/**
	 * A {@code TextOutputStream} is an {@code OutputStream} to which text can be written and from which the written
	 * text can be obtained as an array of {@code String}s.
	 * 
	 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
	 *
	 */
	class TextOutputStream extends java.io.OutputStream {

		/**
		 * The {@code String}s representing the text that has been written to this {@code TextOutputStream}.
		 */
		LinkedList<String> buffer = new LinkedList<String>();

		/**
		 * The current line of text that has been written to this {@code TextOutputStream}.
		 */
		String current = "";

		@Override
		public void write(int b) throws IOException {
			if ((char) b == '\n') {
				buffer.add(current);
				current = "";
			} else if ((char) b != '\r')
				current += (char) b;
		}

		/**
		 * Returns an array of {@code String}s representing all the text that has been written to this
		 * {@code TextOutputStream}.
		 * 
		 * @return an array of {@code String}s representing all the text that has been written to this
		 *         {@code TextOutputStream}.
		 */
		public String[] lines() {
			return buffer.toArray(new String[0]);
		}

	}
}
