package csi213.projects.sort;

import java.io.PrintStream;
import java.util.Arrays;
import java.util.Random;

/**
 * A {@code QuickSortImproved} instance runs an improved version of the Quicksort algorithm on the array given to it when it is
 * being constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */

/**
 * 
 * @author James Krueger
 *I used this: compared my code and make the according corrections. 
 * https://stackoverflow.com/questions/33884057/quick-sort-stackoverflow-error-for-large-arrays
 *  This let me look and I used their partition code to fix my error. 
 *
 */
public class QuickSortImproved extends QuickSort {

	/**
	 * Constructs a {@code QuickSortImproved} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public QuickSortImproved(int[] a, PrintStream out) {
		super(a, out);
	}

	/**
	 *
	 * @param a
	 *            an {@code int} array
	 * @param start
	 *            the start index
	 * @param end
	 *            the end index
	 * @param depthOfRecursion
	 *            the depth of recursion when this method is being invoked
	 * @param out
	 *            a {@code PrintStream} to show the array at the end of each partitioning
	 
	 */
	// TODO: add some code here
	@Override
	public void quickSort(int[] a, int start, int end, int depthOfRecursion, PrintStream out) 
	{
		
		
		 while(start<end) {
			
		
		

		
	
			 
	//	System.out.println(Arrays.toString(a));		

			int pivotPoint = partition(a, start, end,out);
			//System.out.println("Pivot:" + pivotPoint);
			if(pivotPoint-start <= end-(pivotPoint+1))
				{
					
					quickSort(a,start,pivotPoint,depthOfRecursion+1, out);
					start = pivotPoint+1;
				}
				
			else 		
				{
					
					quickSort(a,pivotPoint+1,end, depthOfRecursion+1, out);
					end = pivotPoint;
				}
		//	System.out.println(Arrays.toString(a));		

		 }
		
		
	}
	
	/**
	 * The partition method
	* @param a
	 * 	 an {@code int} array
	 * @param start
	 * 	the start index
	 * @param end
	 * 	the end index
	 * @param out
	 * 		a {@code PrintStream} to show the array at the end of each partitioning
	 * @return
	 * 	returns a int value 
	 */
	
	@Override
	int partition(int a[ ], int start, int end,PrintStream out)
	
	 {
			
		int x = a[(start+end)/2];
        int i = start-1;
        int j = end+1;
//System.out.println("Calling" + start +" end" + end);
        while (true) 
        {
  //      	System.out.println(Arrays.toString(a));		
    //    	System.out.println("a[i+1] " + " " + a[i+1]+ " "+" A of j"+" "+ a[j-1]+" A of x "+ " " +x);
            while (a[++i] < x);
            while (a[--j]> x);

      //     System.out.println("Element i " +i+" "+ "Element j"+j);
            if (i < j)
            	
            {
                int tmp = a[i];
                a[i] = a[j];
                a[j] = tmp;
            } else
            
            {
                return j;
            }
        }
	 }

	
	
	  
	
	

	/**
	 * The main method of the {@code QuickSortImproved} class.
	 * 
	 * @param args
	 *            the program arguments
	 */
	public static void main(String[] args) {
		for (int size = 10; size <= 100000; size *= 10) {
			
			int[] a = createSortedArray(size);
			int[] b = shuffle(a, new Random(0));
			QuickSortImproved s = new QuickSortImproved(b, null);
			System.out
					.print("array of size " + size + " sorted " + (Arrays.equals(a, b) ? "correctly" : "incorrectly"));
			System.out.println(String.format(" in %,.3f milliseconds", 1.0e-6 * s.duration()));
		}
		System.out.println();

		for (int size = 10; size <= 100000; size *= 10) {
			int[] a = createSortedArray(size);
			int[] b = Arrays.copyOf(a, size);
			QuickSortImproved s = new QuickSortImproved(b, null);
			System.out.print(
					"ordered array of size " + size + " sorted " + (Arrays.equals(a, b) ? "correctly" : "incorrectly"));
			System.out.println(String.format(" in %,.3f milliseconds", 1.0e-6 * s.duration()));
		}
		System.out.println();

		for (int size = 10; size <= 100000; size *= 10) {
			int[] a = new int[size];
			int[] b = Arrays.copyOf(a, size);
			QuickSortImproved s = new QuickSortImproved(b, null);
			System.out.print("array containing " + size + " zeroes sorted "
					+ (Arrays.equals(a, b) ? "correctly" : "incorrectly"));
			System.out.println(String.format(" in %,.3f milliseconds", 1.0e-6 * s.duration()));
		}
	}

	/**
	 * Constructs an {@code int} array that is sorted.
	 * 
	 * @param size
	 *            the size of the array
	 * @return an {@code int} array that is sorted
	 */
	public static int[] createSortedArray(int size) {
		int[] a = new int[size];
		for (int i = 0; i < size; i++)
			a[i] = i;
		return a;
	}

	/**
	 * Returns an array containing the elements from the specified array in some random order
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param r
	 *            a {@code Random} instance for random number generation
	 * @return an array containing the elements from the specified array in some random order
	 */
	public static int[] shuffle(int[] a, Random r) {
		a = Arrays.copyOf(a, a.length);
		for (int i = 0; i < a.length; i++) {
			int index = (int) (r.nextDouble() * (a.length - i)) + i;
			int temp = a[i];
			a[i] = a[index];
			a[index] = temp;
		}
		return a;
	}

}
