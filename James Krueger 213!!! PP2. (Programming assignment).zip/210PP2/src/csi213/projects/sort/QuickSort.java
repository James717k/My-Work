package csi213.projects.sort;

import java.io.PrintStream;
import java.util.Arrays;

/**
 * A {@code QuickSort} instance runs the Quicksort algorithm on the array given to it when it is being constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class QuickSort extends Sort {

	/**
	 * The number of recursive invocations performed during sorting.
	 */
	protected long numberOfRecursiveInvocations;

	/**
	 * The maximum depth of recursion occurred during sorting.
	 */
	protected long maximumDepthOfRecursion;

	/**
	 * Constructs a {@code QuickSort} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public QuickSort(int[] a, PrintStream out) {
		super(a, out);
	}

	/**
	 * Sorts the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	protected void sort(int[] a, PrintStream out) {
		quickSort(a, 0, a.length - 1, 1, out);
	}

	/**
	 * Sorts the specified array using the Quicksort algorithm.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param start
	 *            the start index
	 * @param end
	 *            the end index
	 * @param depthOfRecursion
	 *            the depth of recursion when this method is being invoked
	 * @param out
	 *            a {@code PrintStream} to show the array at the end of each partitioning
	 
	 */
	
	void quickSort(int[] a, int start, int end, int depthOfRecursion, PrintStream out) {
		// TODO: add some code here

		numberOfRecursiveInvocations++; //This starts the incerement the amount of the invocations
	
		//System.out.print("Invocation " + numberOfRecursiveInvocations + "quicksort " + start+","+ end+","+ depthOfRecursion +","); <-- This was to see why my code was not giving me the right number for m
		
			
		if (start < end) 
		 {
				 

			int pivotPoint = partition(a, start, end,out);
			
		//	System.out.println(pivotPoint);
			 if (out != null) // do NOT delete this statement
	                out.println(Arrays.toString(a));
			
		 quickSort(a, start, pivotPoint-1,depthOfRecursion+1, out);
		 
	
		 quickSort(a, pivotPoint+1, end, depthOfRecursion+1, out);
		 } 
		if(maximumDepthOfRecursion<depthOfRecursion+1) {
		maximumDepthOfRecursion=depthOfRecursion;
		
	}
	}
	 
	
	/**1
	 * 
	 * @param a
	 * 	 an {@code int} array
	 * @param start
	 * 	the start index
	 * @param end
	 * 	the end index
	 * @param out
	 * 		a {@code PrintStream} to show the array at the end of each partitioning
	 * @return
	 * 	returns a int value 
	 */
	
	int partition(int a[ ], int start, int end,PrintStream out)
	
	 {
			
	 int pivotValue = a[start];
	 
	 int endOfLeftList = start;
	 
	 for (int scan = start + 1; scan <= end; scan ++)
		 
	 {
		if(!(a[scan]<pivotValue)) {
	
			 numberOfComparisons++;
			 
			//This increases the amount of the comparisons when the if happens
				
		}	
		
	 if (a[scan] < pivotValue) {
			
		 numberOfComparisons++;	
		
		 //This increases the amount of the comparisons when the if happens
		// System.out.println("A of scan" + " "+ a[scan] + " pivot Value "+ pivotValue);
	 endOfLeftList ++;
	 swap(a, endOfLeftList, scan);
	 
	
		
	
	 }
	 
	 }

	 swap(a, start, endOfLeftList);  
	
	 return endOfLeftList; 
	  
	 }	 

	/**
	 * Swaps the specified entries in the specified array.
	 * 
	 * @param a
	 *            a an {@code int} array
	 * @param i
	 *            an index
	 * @param j
	 *            an index
	 */
	protected void swap(int[] a, int i, int j) {
		int temp = a[j];
		numberOfArrayElementUpdates++;
		a[j] = a[i];
		numberOfArrayElementUpdates++;
		a[i] = temp;
		
	i++;
	}

	/**
	 * Returns the number of recursive invocations performed during sorting.
	 * 
	 * @return the number of recursive invocations performed during sorting
	 */
	public long numberOfRecursiveInvocations() {
		return numberOfRecursiveInvocations;
	}

	/**
	 * Returns the maximum depth of recursion occurred during sorting.
	 * 
	 * @return the maximum depth of recursion occurred during sorting
	 */
	public long maximumDepthOfRecursion() {
		return maximumDepthOfRecursion;
	}

	/**
	 * The main method of the {@code QuickSort} class.
	 * 
	 * @param args
	 *            the program arguments
	 */
	public static void main(String[] args) {
		int[] a = { 5, 3, 1, 2, 4 };
		QuickSort s = new QuickSort(a, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("number of recursive invocations: %,d", s.numberOfRecursiveInvocations()));
		System.out.println(String.format("maximum depth of recursion: %,d", s.maximumDepthOfRecursion()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
		System.out.println();

		int[] b = { 7, 6, 5, 1, 2, 3, 4 };
		s = new QuickSort(b, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("number of recursive invocations: %,d", s.numberOfRecursiveInvocations()));
		System.out.println(String.format("maximum depth of recursion: %,d", s.maximumDepthOfRecursion()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
	}

}
