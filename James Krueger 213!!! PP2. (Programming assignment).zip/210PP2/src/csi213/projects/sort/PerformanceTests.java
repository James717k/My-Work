package csi213.projects.sort;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

/**
 * An instance of {@code PerformanceTests} tests the performance of sorting algorithms.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 * 
 */
public class PerformanceTests {

	/**
	 * Tests the performance of all sorting implementations.
	 * 
	 * @throws Exception
	 *             if an error occurs
	 */
	@Test
	public void testPerformance() throws Exception {
		for (int size = 10; size <= 100000; size *= 10) {
			testPerformance(QuickSortImproved.shuffle(QuickSortImproved.createSortedArray(size), new Random(0)),
					size == 10, "unsorted");
			testPerformance(QuickSortImproved.createSortedArray(size), size == 10, "sorted");
			testPerformance(new int[size], size == 10, "zeros");
		}
	}

	/**
	 * Tests performance of all sorting implementations using the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param resetResultFiles
	 *            a flag indicating whether or not the result files need to be reset
	 * @param label
	 *            a {@code String} representing the nature of the array
	 * @throws Exception
	 *             if an error occurs when constructing a {@code Sort} instance
	 */
	void testPerformance(int[] a, boolean resetResultFiles, String label) throws Exception {
		System.out.print("running sorting algorithms on an array of size " + a.length + " (" + label + ") ...");
		long startTime = System.currentTimeMillis();

		PrintStream outTime = resetResultFiles ? new PrintStream(label + "_time.csv")
				: new PrintStream(new FileOutputStream(label + "_time.csv", true));
		PrintStream outComparisons = resetResultFiles ? new PrintStream(label + "_comparisons.csv")
				: new PrintStream(new FileOutputStream(label + "_comparisons.csv", true));
		PrintStream outUpdates = resetResultFiles ? new PrintStream(label + "_updates.csv")
				: new PrintStream(new FileOutputStream(label + "_updates.csv", true));
		PrintStream outInvocations = resetResultFiles ? new PrintStream(label + "_invocations.csv")
				: new PrintStream(new FileOutputStream(label + "_invocations.csv", true));
		PrintStream outDepth = resetResultFiles ? new PrintStream(label + "_depth.csv")
				: new PrintStream(new FileOutputStream(label + "_depth.csv", true));

		if (resetResultFiles) {
			String header = "size; bubble sort; selection sort; insertion sort; Quicksort";
			outTime.println(header);
			outComparisons.println(header);
			outUpdates.println(header);
			outInvocations.println("size; QuickSort");
			outDepth.println("size; QuickSort");
		}

		print(a.length, outTime, outComparisons, outUpdates, outInvocations, outDepth);
		testPerformance(BubbleSort.class, a, outTime, outComparisons, outUpdates, outInvocations, outDepth);
		testPerformance(SelectionSort.class, a, outTime, outComparisons, outUpdates, outInvocations, outDepth);
		testPerformance(InsertionSort.class, a, outTime, outComparisons, outUpdates, outInvocations, outDepth);
		testPerformance(QuickSortImproved.class, a, outTime, outComparisons, outUpdates, outInvocations, outDepth);
		println(outTime, outComparisons, outUpdates, outInvocations, outDepth);

		outTime.close();
		outComparisons.close();
		outUpdates.close();
		outInvocations.close();
		outDepth.close();

		System.out.println(String.format("%,.1f seconds", 1.0e-3 * (System.currentTimeMillis() - startTime)));
	}

	/**
	 * Tests the performance of the specified sorting implementation using the specified array.
	 * 
	 * @param c
	 *            a sorting implementation
	 * @param a
	 *            an {@code int} array
	 * @param outTime
	 *            a {@code PrintStream} to record the duration of sorting
	 * @param outComparisons
	 *            a {@code PrintStream} to record the number of comparisons during sorting
	 * @param outUpdates
	 *            a {@code PrintStream} to record the number of array element updates during sorting
	 * @param outInvocations
	 *            a {@code PrintStream} to record the number of recursive invocations during sorting
	 * @param outDepth
	 *            a {@code PrintStream} to record the maximum of depth of recursion during sorting
	 * @throws Exception
	 *             if an error occurs when constructing a {@code Sort} instance
	 */
	protected void testPerformance(Class<? extends Sort> c, int[] a, PrintStream outTime, PrintStream outComparisons,
			PrintStream outUpdates, PrintStream outInvocations, PrintStream outDepth) throws Exception {
		Constructor<? extends Sort> constructor = c.getConstructor(int[].class, PrintStream.class);
		long sum = 0;
		long count = 0;
		long startTime = System.nanoTime();
		Sort s = constructor.newInstance(Arrays.copyOf(a, a.length), null);
		sum += s.duration();
		count++;
		while (System.nanoTime() - startTime < 1e9) {
			s = constructor.newInstance(Arrays.copyOf(a, a.length), null);
			sum += s.duration();
			count++;
		}
		outTime.print("; " + 1.0e-9 * sum / count);
		outComparisons.print("; " + s.numberOfComparisons());
		outUpdates.print("; " + s.numberOfArrayElementUpdates());
		if (s instanceof QuickSortImproved) {
			outInvocations.print("; " + ((QuickSortImproved) s).numberOfRecursiveInvocations());
			outDepth.print("; " + ((QuickSortImproved) s).maximumDepthOfRecursion());
		}
	}

	/**
	 * Writes the specified number to the specified {@code PrintStream}s
	 * 
	 * @param n
	 *            a {@code Number}
	 * @param streams
	 *            {@code PrintStream}s
	 */
	protected void print(Number n, PrintStream... streams) {
		for (PrintStream stream : streams)
			stream.print(n);
	}

	/**
	 * Terminates the current line in each of the specified {@code PrintStream}s
	 * 
	 * @param streams
	 *            {@code PrintStream}s
	 */
	protected void println(PrintStream... streams) {
		for (PrintStream stream : streams)
			stream.println();
	}

}
