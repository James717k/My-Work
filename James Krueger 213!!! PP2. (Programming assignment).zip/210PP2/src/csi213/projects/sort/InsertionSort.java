package csi213.projects.sort;

import java.io.PrintStream;
import java.util.Arrays;

/**
 * A {@code InsertionSort} instance runs the insertion sort algorithm on the array given to it when it is being
 * constructed.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
public class InsertionSort extends Sort {

	/**
	 * Constructs a {@code InsertionSort} instance while sorting the specified array.
	 * 
	 * @param a
	 *            an {@code int} array to sort
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	public InsertionSort(int[] a, PrintStream out) {
		super(a, out);
	}

	/**
	 * Sorts the specified array.
	 * 
	 * @param a
	 *            an {@code int} array
	 * @param out
	 *            a {@code PrintStream} to show the array at each important point during sorting
	 */
	protected void sort(int[] a, PrintStream out) {
		for (int index = 1; index <= a.length - 1 ; index++){
            // TODO: add some code here


            int unSortedValue = a[index];
            int scan = index; 



            while(true) { 
            	if(!(scan >0))
                    break;
        numberOfComparisons++;
        if(!(scan >0 && a[scan-1]> unSortedValue))
            break;
                a[scan] = a[scan-1]; numberOfArrayElementUpdates++; 
                scan--;


            }

            a[scan] = unSortedValue;  numberOfArrayElementUpdates++;

            if (out != null) // do NOT delete this statement
                out.println(Arrays.toString(a));
        }

    }

	/**
	 * The main method of the {@code InsertionSort} class.
	 * 
	 * @param args
	 *            the program arguments
	 */
	public static void main(String[] args) {
		int[] a = { 5, 3, 1, 2, 4 };
		InsertionSort s = new InsertionSort(a, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
		System.out.println();

		int[] b = { 7, 6, 5, 1, 2, 3, 4 };
		s = new InsertionSort(b, System.out);
		System.out.println(String.format("number of comparisons: %,d", s.numberOfComparisons()));
		System.out.println(String.format("number of array element updates: %,d", s.numberOfArrayElementUpdates()));
		System.out.println(String.format("duration of sorting: %,.3f (milliseconds)", 1.0e-6 * s.duration()));
	}

}
