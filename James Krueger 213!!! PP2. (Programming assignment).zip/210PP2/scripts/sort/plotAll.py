import pandas as pd
import os
import numpy as np
from matplotlib import pyplot as plt
from math import inf
from sklearn import linear_model


def extrapolate(x, y):
    x_extra = np.arange(5) 
    x_extra = max(x) * np.power(10, x_extra) # the x values for extrapolation
    ftn = '$0$'

    x = x[y != 0]  # remove x values whose corresponding y values are zeros
    y = y[y != 0]  # remove y values that are zeros
    
    x = x.reshape((-1, 1))
    x_training = np.hstack((np.ones(((len(x), 1))), np.log(x), np.log(np.log(x)))) # prepare training data
    y_training = np.log(y.reshape((-1, 1)))
    
    if (len(x_training[:,0]) > 2): # if enough training data
        regr = linear_model.LinearRegression()
        regr.fit(x_training, y_training, sample_weight=np.power(np.arange(len(x_training[:,0])) + 1, 2.5))
        
        features_extra = x_extra.reshape((-1, 1)) # features for extrapolation
        features_extra = np.hstack((np.ones(((len(features_extra), 1))), np.log(features_extra), np.log(np.log(features_extra))))
        y_extra = np.exp(regr.predict(features_extra)) # extrapolate
        y_extra = y_extra.reshape(np.shape(x_extra)) # result extrapolation
        log_exp = round(regr.coef_[0, 2])
        if (log_exp <= 0):
            ftn = "$n^{{{b:.0f}}}$".format(b=regr.coef_[0, 1])
        else:
            ftn = "$n^{{{b:.0f}}}\log n$".format(b=regr.coef_[0, 1])
    else:
        y_extra = np.zeros(np.shape(x_extra)) # result = array of zeros
    return x_extra, y_extra, ftn


def plot(metric, ylabel, array_types):
    markers = ['o', 'x', '+', '.']
    line_styles = [':', '--', '-.', '-']
    scales = ['linear', 'log']
    figure = plt.figure(figsize=(12, 7))
    i = 1 # subfigure index
    ymax = 0 # variable for finding the maximum y value.
    ymin = inf # variable for finding the minimum y value.
    for scale in scales: # either 'linear' or 'log'
        for label in array_types: # either 'unsorted', 'sorted', or 'zeros'
            df = pd.read_csv('../../' + label + '_' + metric + '.csv', delimiter=';')
            ax = plt.subplot(2, 3, i)
            c = 0 # curve index
            for col in df.columns:
                if (col == 'size'):
                    x = df['size'].to_numpy() # the x values (i.e., array sizes)
                else:
                    y = df[col].to_numpy() # the y values
                    x_extra, y_extra, ftn = extrapolate(x, y) # extrapolate the curve
                    ax.plot(np.concatenate((x, x_extra)), np.concatenate((y, y_extra)), # draw the curve
                            label=col + ': ' + ftn, marker=markers[c], linewidth=1, 
                            linestyle=line_styles[c], fillstyle='none')
                    c += 1 # increase the curve index
                    ymax = max(ymax, max(np.concatenate((y, y_extra)))) # track the maximum y value
                    ymin = min(ymin, min(np.concatenate((y, y_extra)))) # track the minimum y value
                    
            plt.title(label) # show the title of the sub-plot
            ax.set_xlabel('array size ($n$)')
            ax.set_ylabel(ylabel)
            plt.xticks(np.concatenate((x, x_extra)))

            plt.xscale('log')
            plt.yscale(scale)
            
            if scale == 'log' and ymin == 0:
                ymin = 1
            plt.xlim((min(x), max(x_extra)))
            plt.ylim((ymin, ymax))
            
            ax.add_patch(plt.Rectangle((max(x), ymin), max(x_extra) - max(x), ymax - ymin, facecolor='green', alpha=0.05))
            plt.text(max(x), ymin, '  estimated\n', color='green', rotation=0, va='bottom', wrap=True)
            
            ax.legend()
            ax.xaxis.grid(linewidth=0.1)
            ax.yaxis.grid(linewidth=0.1)
            i += 1
        
    figure.tight_layout()
#    plt.show()
    figure.savefig('../../' + metric + '.pdf', format='pdf')


array_types = ['unsorted', 'sorted', 'zeros']
plot('time', 'time (seconds)', array_types)
plot('comparisons', 'number of comparisons', array_types)
plot('updates', 'number of array element updates', array_types)

